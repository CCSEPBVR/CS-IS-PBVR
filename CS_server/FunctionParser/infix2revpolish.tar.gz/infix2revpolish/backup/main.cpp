// gcc polish.c -o polish
#include <iostream>
#include <string>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct Node Node;

#define MAX_NODES   512
#define MAX_EXP_LEN 512

struct Node {
    char exp[MAX_EXP_LEN];
    Node* left;
    Node* right;
};

class ExpressionConverter
{
public:
    Node* nodes;
    Node* root;
    int   nb_node_used;

public:
    ExpressionConverter( void )
        {
            nodes = new Node[MAX_NODES];
            nb_node_used = 0;
            root = this->create_node();
        }

    ~ExpressionConverter()
        {
            delete [] nodes;
        }

    void setExpression( std::string expression )
        {
            expression.copy( root->exp, expression.size() );
        }

    int convertExpression( void )
        {
            this->remove_space( root->exp );
            std::cout<<"expression: "<<root->exp<<std::endl;

            if (this->parse_expression( root ) < 0) {
                fprintf(stderr, "parser error\n");
                return -1;
            }

            std::cout<<"reverse polish notation: ";
            this->traverse_tree_postorder( root );
            std::cout<<std::endl;

            return 1;
        }

protected:
    //配列nodesを二分木として扱う
    Node* create_node()
        {
            if (nb_node_used == MAX_NODES)
                return NULL;
            else
                return &nodes[nb_node_used++];
        }

    void remove_space(char *exp)
        {
            char *dst = exp;
            char *src = exp;

            while (*src) {
                if (*src == ' ')
                    src++;
                else
                    *(dst++) = *(src++);
            }

            *dst = '\0';
        }

    //最外の括弧を取り除く
    int remove_bracket(char *exp)
        {
            size_t i;
            size_t len = strlen(exp);
            int nest = 1;

            //最外の括弧の有無を判定。無ければ脱出
            if (!(exp[0] == '(' && exp[len - 1] == ')'))
                return 0;

            //右括弧と左括弧の数が同じかどうかを判定
            for (i = 1; i < len - 1; i++) {
                if (exp[i] == '(')
                    nest++;
                else if (exp[i] == ')')
                    nest--;

                //if (nest == 0)効果が不明、とりあえずコメントアウト
                //return 0;
            }

            if (nest != 1) {
                fprintf(stderr, "unbalanced bracket: %s\n", exp);
                return -1;
            }

            //最外の括弧を取り除く
            for (i = 0; i < len - 2; i++) {
                exp[i] = exp[i + 1];
            }
            exp[i] = '\0';

            //二重、三重括弧の場合の、最外の括弧を取り除く
            if (exp[0] == '(')
                remove_bracket(exp);

            return 0;
        }

    //最も優先度の低い演算子の位置を取得
    int get_pos_operator(char *exp)
        {
            int i;
            int pos_op = -1;
            int nest = 0;
            int priority;
            int priority_lowest = 4;//最低の優先度を保持

            if (!exp)
                return -1;

            for (i = 0; exp[i]; i++) {
                switch (exp[i]) {
                case '=': priority = 1; break;
                case '+': priority = 2; break;
                case '-': priority = 2; break;
                case '*': priority = 3; break;
                case '/': priority = 3; break;
                case '(': nest++; continue;
                case ')': nest--; continue;
                default: continue;
                }
                //括弧の中は優先度が高いので、priority_lowestの更新を飛ばす
                if (nest == 0 && priority <= priority_lowest) {
                    priority_lowest = priority;
                    pos_op = i;
                }
            }
            //括弧の中を除いて、演算子が存在しない場合、posi_op=-1は更新されない
            return pos_op;
        }

    int parse_expression(Node* node)
        {
            int pos_op;
            size_t len_exp;

            if (!node)
                return -1;

            //nodeの中の優先度の低い演算子(+や-)の位置を取得
            pos_op = get_pos_operator(node->exp);

            //括弧の中を除いて、演算子が存在しない場合、処理を終了
            if (pos_op == -1) {
                node->left  = NULL;
                node->right = NULL;

                return 0;
            }

            len_exp = strlen(node->exp);

            //node->leftにノードを追加
            node->left  = create_node();

            if (!node->left) {
                fprintf(stderr, "expression too long\n");
                return -1;
            }

            //node->left->exp に node->exp を先頭から pos_op 文字コピー
            strncpy(node->left->exp, node->exp, pos_op);

            //node->left->expの最外の括弧を取り除く
            if (remove_bracket(node->left->exp) < 0)
                return -1;

            //node->left->expに対する分解処理を繰り返す
            if (parse_expression(node->left) < 0)
                return -1;

            //node->rightにノードを追加
            node->right = create_node();

            if (!node->right) {
                fprintf(stderr, "expression too long\n");
                return -1;
            }

            //node->right->exp に node->exp をpos_op+1ずらした先頭から len_exp-pos_op 文字コピー
            strncpy(node->right->exp, node->exp + pos_op + 1, len_exp - pos_op);

            //node->right->expの最外の括弧を取り除く
            if (remove_bracket(node->right->exp) < 0)
                return -1;

            //node->right->expに対する分解処理を繰り返す
            if (parse_expression(node->right) < 0)
                return -1;

            //演算子を文字列の先頭に入力
            node->exp[0] = node->exp[pos_op];
            node->exp[1] = '\0';

            //演算子が一文字を仮定、関数の取扱が無い

            return 0;
        }

    void traverse_tree_postorder(Node* node)
        {
            if (node->left)
                traverse_tree_postorder(node->left);
            if (node->right)
                traverse_tree_postorder(node->right);

            printf(node->exp);
        }

    void traverse_tree_inorder(Node* node)
        {
            if (node->left && node->right)
                printf("(");

            if (node->left)
                traverse_tree_inorder(node->left);

            printf(node->exp);

            if (node->right)
                traverse_tree_inorder(node->right);

            if (node->left && node->right)
                printf(")");
        }

    void traverse_tree_preorder(Node* node)
        {
            printf(node->exp);

            if (node->left)
                traverse_tree_preorder(node->left);

            if (node->right)
                traverse_tree_preorder(node->right);
        }

    double calculate(Node* node)
        {
            double left_operand, right_operand;

            if (node->left && node->right) {
                left_operand  = calculate(node->left);
                right_operand = calculate(node->right);

                if (0 == strcmp(node->exp, "+"))
                    return left_operand + right_operand;
                else if (0 == strcmp(node->exp, "-"))
                    return left_operand - right_operand;
                else if (0 == strcmp(node->exp, "*"))
                    return left_operand * right_operand;
                else if (0 == strcmp(node->exp, "/"))
                    return left_operand / right_operand;
                else
                    return 0.0;
            }
            else {
                return atof(node->exp);
            }
        }
};

int main()
{
    ExpressionConverter exprconv;

    std::string expression;
    std::cout<<"input expression: "<<std::endl;
    std::cin>>expression;
    std::cout<<std::endl;

    exprconv.setExpression( expression );

    exprconv.convertExpression();

    return 0;
}
