#ifndef _REVERSEPOLISHNOTATION
#define _REVERSEPOLISHNOTATION

#include <iostream>
#include <math.h>
#include <sys/time.h>

#include "Token.h"

#define MAXVAL 256
#define NUMVAR 95 //変数の数と一致すること

//void push( float );
//float pop( void );
/*
//変数名のリスト
enum VarName {
    X, Y, Z,//2
    Q1,DQ1X,DQ1Y,DQ1Z,  Q2,DQ2X,DQ2Y,DQ2Z,  Q3,DQ3X,DQ3Y,DQ3Z,//14
    Q4,DQ4X,DQ4Y,DQ4Z,  Q5,DQ5X,DQ5Y,DQ5Z,  Q6,DQ6X,DQ6Y,DQ6Z,//26
    Q7,DQ7X,DQ7Y,DQ7Z,  Q8,DQ8X,DQ8Y,DQ8Z,  Q9,DQ9X,DQ9Y,DQ9Z,//38
    Q10,DQ10X,DQ10Y,DQ10Z,  Q11,DQ11X,DQ11Y,DQ11Z,  Q12,DQ12X,DQ12Y,DQ12Z,//50
    Q13,DQ13X,DQ13Y,DQ13Z,  Q14,DQ14X,DQ14Y,DQ14Z,  Q15,DQ15X,DQ15Y,DQ15Z,//62
    Q16,DQ16X,DQ16Y,DQ16Z,  Q17,DQ17X,DQ17Y,DQ17Z,  Q18,DQ18X,DQ18Y,DQ18Z,//74
    C1, C2, C3, C4, C5, C6, C7, C8, C9, C10,//84
    A1, A2, A3, A4, A5, A6, A7, A8, A9, A10//94
};

//数式表現のためのトークン
enum Token {
    //なにもなし
    NON,//0
    //変数
    VARIABLE,//1
    //数値
    VALUE,//2
    //二項演算子
    PLUS, MINUS, MULTI, DIVIDE, POW,//7
    //単項演算子としてのマイナス
    MINUSF,//8
    //単項関数
    SQRT, CBRT, LOG, LOG10, EXP, ABS, FLOOR, CEIL,//16
    SIN, COS, TAN, ASIN, ACOS, ATAN, SINH, COSH, TANH, ASINH, ACOSH, ATANH,//28
    HEAVI,RECT,//30
    //二項関数
    SIGMOID, GAUSS,//32
    //関数内のカンマ
    COMMA,//33
    //終了
    END,//34
    //ここまでが、逆ポーランド記法と共有できるトークンの値
    //左括弧、右括弧
    LEFT, RIGHT
};
*/
class ReversePolishNotation
{
public:
    //逆ポーランド記法のデータ構造
    int   *m_exp_token;
    int   *m_variable_name;
    float *m_variable_value;
    float *m_number;

    //スタックとポインタ
    int m_sp;
    float* m_stack;

public:
    ReversePolishNotation( void )
        {
            m_exp_token = new int[MAXVAL];
            m_variable_name = new int[MAXVAL];
            m_variable_value = new float[NUMVAR];//変数の数だけ必要
            m_number = new float[MAXVAL];
            m_stack = new float[MAXVAL];
        }

    ~ReversePolishNotation( void )
        {
            delete[] m_exp_token;
            delete[] m_variable_name;
            delete[] m_variable_value;
            delete[] m_number;
            delete[] m_stack;
        }

public:
    void setExpToken( int* exp_token, int size )
        {
            for( int i = 0; i < size; i++ )
            {
                m_exp_token[i] = exp_token[i];
            }
        }

    void setVariableName( int* name, int size )
        {
            for( int i = 0; i < size; i++ )
            {
                m_variable_name[i] = name[i];
            }
        }

    void setNumber( float* num, int size )
        {
            for( int i = 0; i < size; i++ )
            {
                m_number[i] = num[i];
            }
        }

    void setVariableValue( float* value )
        {
            for( int i = 0; i < NUMVAR; i++ )
            {
                m_variable_value[i] = value[i];
            }
        }

public:
    float eval( void )
        {
            m_sp = 0; //スタックポインタの初期化

            int*   expr = m_exp_token;
            int*   name = m_variable_name;
            float* value = m_variable_value;
            float* number = m_number;

            float tmp1, tmp2, tmp3;

            while( *expr != END )
            {
                switch( *expr )
                {
                    //変数
                case VARIABLE:
                    push( value[*name] );
                    break;

                    //数値
                case VALUE:
                    push( *number );
                    break;

                    //二項演算子
                case PLUS:
                    tmp1 = pop();
                    tmp2 = pop();
                    tmp3 = tmp2 + tmp1;
                    push( tmp3 );
                    break;
                case MINUS:
                    tmp1 = pop();
                    tmp2 = pop();
                    tmp3 = tmp2 - tmp1;
                    push( tmp3 );
                    break;
                case MULTI:
                    tmp1 = pop();
                    tmp2 = pop();
                    tmp3 = tmp2 * tmp1;
                    push( tmp3 );
                    break;
                case DIVIDE:
                    tmp1 = pop();
                    tmp2 = pop();
                    tmp3 = tmp2 / tmp1;
                    push( tmp3 );
                    break;
                case POW:
                    tmp1 = pop();
                    tmp2 = pop();
                    tmp3 = pow( tmp2, tmp1 );
                    push( tmp3 );
                    break;

                    //単項演算子としてのマイナス
                case MINUSF:
                    tmp1 = pop();
                    tmp2 = -tmp1;
                    push( tmp2 );
                    break;

                    //単項関数
                case SQRT:
                    tmp1 = pop();
                    tmp2 = sqrt( tmp1 );
                    push( tmp2 );
                    break;
                case CBRT:
                    tmp1 = pop();
                    tmp2 = cbrt( tmp1 );
                    push( tmp2 );
                    break;
                case LOG:
                    tmp1 = pop();
                    tmp2 = log( tmp1 );
                    push( tmp2 );
                    break;
                case LOG10:
                    tmp1 = pop();
                    tmp2 = log10( tmp1 );
                    push( tmp2 );
                    break;
                case EXP:
                    tmp1 = pop();
                    tmp2 = exp( tmp1 );
                    push( tmp2 );
                    break;
                case ABS:
                    tmp1 = pop();
                    tmp2 = fabs( tmp1 );
                    push( tmp2 );
                    break;
                case FLOOR:
                    tmp1 = pop();
                    tmp2 = floor( tmp1 );
                    push( tmp2 );
                    break;
                case CEIL:
                    tmp1 = pop();
                    tmp2 = ceil( tmp1 );
                    push( tmp2 );
                    break;
                case SIN:
                    tmp1 = pop();
                    tmp2 = sin( tmp1 );
                    push( tmp2 );
                    break;
                case COS:
                    tmp1 = pop();
                    tmp2 = cos( tmp1 );
                    push( tmp2 );
                    break;
                case TAN:
                    tmp1 = pop();
                    tmp2 = tan( tmp1 );
                    push( tmp2 );
                    break;
                case ASIN:
                    tmp1 = pop();
                    tmp2 = asin( tmp1 );
                    push( tmp2 );
                    break;
                case ACOS:
                    tmp1 = pop();
                    tmp2 = acos( tmp1 );
                    push( tmp2 );
                    break;
                case ATAN:
                    tmp1 = pop();
                    tmp2 = atan( tmp1 );
                    push( tmp2 );
                    break;
                case SINH:
                    tmp1 = pop();
                    tmp2 = sinh( tmp1 );
                    push( tmp2 );
                    break;
                case COSH:
                    tmp1 = pop();
                    tmp2 = cosh( tmp1 );
                    push( tmp2 );
                    break;
                case TANH:
                    tmp1 = pop();
                    tmp2 = tanh( tmp1 );
                    push( tmp2 );
                    break;
                case ASINH:
                    tmp1 = pop();
                    tmp2 = asinh( tmp1 );
                    push( tmp2 );
                    break;
                case ACOSH:
                    tmp1 = pop();
                    tmp2 = acosh( tmp1 );
                    push( tmp2 );
                    break;
                case ATANH:
                    tmp1 = pop();
                    tmp2 = atanh( tmp1 );
                    push( tmp2 );
                    break;
                case HEAVI:
                    tmp1 = pop();
                    tmp2 = tmp1<=0 ? 0 : 1;
                    push( tmp2 );
                    break;
                case RECT:
                    tmp1 = pop();
                    tmp2 = fabs(tmp1)>0.5 ? 0 : 1;
                    push( tmp2 );
                    break;

                    //二項関数
                case SIGMOID:    // 1/(1+e^ax)
                    tmp1 = pop();//a
                    tmp2 = pop();//x
                    tmp3 = 1.0/(1.0+exp(tmp1*tmp2));
                    push( tmp3 );
                    break;
                case GAUSS:       //e^( -(x)^2 / 2s )
                    tmp1 = pop();//s
                    tmp2 = pop();//x
                    tmp3 = exp(-tmp2*tmp2/(2*tmp1) );
                    push( tmp3 );
                    break;

                    //カンマ
                case COMMA:
                    break;

                default:
                    std::cout<<"unknown token."<<std::endl;
                } // end of switch

                expr++;
                name++;
                number++;
            } //end of while

            tmp1 = pop();
            return tmp1;
        }

protected:
    /* push: fを値スタックにプッシュする*/
    void push( float f )
        {
            if ( m_sp < MAXVAL )
            {
                m_stack[m_sp++] = f; // stack[sp]=f; sp++; と同じ
            }
            else
            {
                printf("error: stack full, can't push %g\n", f);
            }
        }

    /* pop: スタックをポップし，一番上の値を返す*/
    float pop( void )
        {
            if ( m_sp > 0 )
            {
                return m_stack[--m_sp]; // sp--; return stack[sp]; と同じ
            }
            else
            {
		printf("error: stack empty\n");
		return 0.0;
            }
        }
};

#endif
